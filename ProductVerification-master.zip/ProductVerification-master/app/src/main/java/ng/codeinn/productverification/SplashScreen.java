package ng.codeinn.productverification;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

import ng.codeinn.productverification.data.AdminPassword;

public class SplashScreen extends AppCompatActivity {
    private static final String TAG = " ";
    private FirebaseFirestore firestore;
    private ProgressBar progressBar;
    Button verifyProductButton, adminSignInButtton;
    private NetworkInfo networkInfo;
    private ConnectivityManager connectivityManager;
    private boolean isNetworkConnect;
    private Context context;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);

        firestore = FirebaseFirestore.getInstance();

        context = this;
        progressBar = findViewById(R.id.splash_screen_progress);
        progressBar.setVisibility(View.GONE);

        verifyProductButton = findViewById(R.id.verify_button);
        adminSignInButtton = findViewById(R.id.admin_button);

        verifyProductButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SplashScreen.this, VerificationActivity.class));
            }
        });
        adminSignInButtton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                adminPasswordDialog(v);

            }

        });

    }

    private void adminPasswordDialog(final View view){

        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        View dialogView = this.getLayoutInflater().inflate(R.layout.admin_auth_dialog, null);
        dialog.setView(dialogView);
        final EditText adminPasswordEditText = (EditText) dialogView.findViewById(R.id.admin_password);

        dialog.setTitle("Input Admin Password");

        dialog.setPositiveButton("Auth admin", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                connectivityManager = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager != null) {
                    networkInfo = connectivityManager.getActiveNetworkInfo();
                }
//        NetworkInfo networkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
                if (networkInfo != null) {
                    isNetworkConnect = networkInfo.isConnected();
                }
                if (networkInfo != null && isNetworkConnect) {

                    boolean cancel = false;

                    String password = adminPasswordEditText.getText().toString();
                    adminPasswordEditText.setError(null);
                    if (TextUtils.isEmpty(password) || password.equals(" ")){
                        cancel = true;
                    } if (cancel) {
                        Toast toast =  Toast.makeText(SplashScreen.this, "Please input a password", Toast.LENGTH_LONG);
                        LinearLayout layout  = (LinearLayout) toast.getView();
                        TextView messageTextView = (TextView) layout.getChildAt(0);
                        messageTextView.setTextSize(20);
                        toast.show();

                    } else {
                        progressBar.setVisibility(View.VISIBLE);
                        adminSignInButtton.setEnabled(false);
                        verifyProductButton.setEnabled(false);
                        Log.i(TAG, "asyncTask this onClick: ");
                        AdminSignInAsyncTask adminSignInAsyncTask = new AdminSignInAsyncTask();
                        adminSignInAsyncTask.execute(password);
                    }
                }
                else {
                    Snackbar snackbar = Snackbar.make(view, "No internet connection!", Snackbar.LENGTH_SHORT);
                    View snackBarView = snackbar.getView();
                    snackBarView.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));
                    TextView textView = (TextView) snackBarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(context.getResources().getColor(R.color.white));
                    snackbar.show();
                }
            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });


        AlertDialog builder = dialog.create();
        builder.show();
    }

    private class AdminSignInAsyncTask extends AsyncTask<String, Void, Void>{

        ArrayList<String > adminPasswords = new ArrayList<>();
        boolean passwordExists = false;
        @Override
        protected Void doInBackground(final String... strings) {

            Log.i(TAG, "asyncTask this doInBackground: started");
            firestore.collection("admin_password")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DocumentSnapshot document : task.getResult()) {
                                    Log.d(TAG, document.getId() + " => " + document.getData());
                                    AdminPassword adminPasswordObject = document.toObject(AdminPassword.class);
                                    adminPasswords.add(adminPasswordObject.getPassword());
                                }
                                for (String password : adminPasswords){
                                    if (strings.length < 1 || strings[0] == null) {
                                        return;
                                    }
                                    if (password.equals(strings[0])) {
                                        progressBar.setVisibility(View.INVISIBLE);
                                        Log.i(TAG, "asyncTask this onComplete: password exists: " + strings[0]);
                                        passwordExists = true;
                                        break;
                                    }
                                }

                                if (passwordExists){
                                    Toast.makeText(SplashScreen.this, "Password authenticated", Toast.LENGTH_SHORT).show();
                                    progressBar.setVisibility(View.GONE);
                                    startActivity(new Intent(SplashScreen.this, AdminActivity.class));
                                    SplashScreen.this.finish();
                                }
                                else {
                                    progressBar.setVisibility(View.GONE);
                                    adminSignInButtton.setEnabled(true);
                                    verifyProductButton.setEnabled(true);
                                    Toast.makeText(SplashScreen.this, "Invalid password", Toast.LENGTH_SHORT).show();
                                }

                            } else {
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });
            return null;
        }
    }

}

