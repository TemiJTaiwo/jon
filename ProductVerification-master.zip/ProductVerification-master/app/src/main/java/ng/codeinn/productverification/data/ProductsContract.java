package ng.codeinn.productverification.data;

import android.provider.BaseColumns;

/**
 * Created by Jer on 19/03/2018.
 */

public class ProductsContract {

    public static final class ProductsEntry implements BaseColumns{
        public static final String 
                TABLE_NAME = "productsList",
                COLUMN_PRODUCT_NAME = "productName",
                COLUMN_MANUFACTURER_NAME = "manufactureName",
                COLUMN_EXPIRATION_DATE = "expirationDate",
                COLUMN_VERIFICATION_CODE = "verificationCode";
    }
}
