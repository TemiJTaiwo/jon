package ng.codeinn.productverification.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Created by Jer on 19/03/2018.
 */

public class ProductsDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "products.db";

    private static final int DATABASE_VERSION = 1;


    public ProductsDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        final String SQL_CREATE_PRODUCTS_TABLE = "CREATE TABLE " + ProductsContract.ProductsEntry.TABLE_NAME + " (" +
                ProductsContract.ProductsEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                ProductsContract.ProductsEntry.COLUMN_PRODUCT_NAME + " TEXT NOT NULL, "  +
                ProductsContract.ProductsEntry.COLUMN_MANUFACTURER_NAME + " TEXT NOT NULL, " +
                ProductsContract.ProductsEntry.COLUMN_EXPIRATION_DATE + " TEXT NOT NULL, " +
                ProductsContract.ProductsEntry.COLUMN_VERIFICATION_CODE + " TEXT NOT NULL" +
                "); ";


        db.execSQL(SQL_CREATE_PRODUCTS_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "  + ProductsContract.ProductsEntry.TABLE_NAME);
        onCreate(db);
    }
}
