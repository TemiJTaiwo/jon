package ng.codeinn.productverification;

import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import ng.codeinn.productverification.Adapters.ProductDetailsAdapter;
import ng.codeinn.productverification.data.ProductsContract;
import ng.codeinn.productverification.data.ProductsDbHelper;
import ng.codeinn.productverification.data.ResponseModel;

public class VerificationActivity extends AppCompatActivity {

    private static final String TAG = "Tag";
    private FirebaseFirestore firebaseFirestore;
    FloatingActionButton verifyFab;
    private Context context;
    Cursor mCursor;
    private ArrayList <ProductDetails> verifiedProductsList;
    private ListView verifiedProductsListView;
    private ProductDetailsAdapter verifiedProductsAdapter;
    private SQLiteDatabase sqLiteDatabase;
    private ProgressBar progressBar;
    private NetworkInfo networkInfo;
    private ConnectivityManager connectivityManager;
    private boolean isNetworkConnect;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verification);

        firebaseFirestore = FirebaseFirestore.getInstance();

        ProductsDbHelper dbHelper = new ProductsDbHelper(this);

        sqLiteDatabase = dbHelper.getWritableDatabase();

        context = this;
        progressBar = findViewById(R.id.verify_progress_bar);
        progressBar.setVisibility(View.GONE);

        verifiedProductsList = new ArrayList<>();
        verifiedProductsListView = (ListView) findViewById(R.id.verified_list_view);
        mCursor = getAllVerifiedProducts();

        if (mCursor.moveToFirst()){
            verifiedProductsListView.setVisibility(View.VISIBLE);
            verifiedProductsList =  loadVerifiedProductsFromCursor(mCursor);
            verifiedProductsAdapter = new ProductDetailsAdapter(this, verifiedProductsList);
            verifiedProductsListView.setAdapter(verifiedProductsAdapter);
        }else verifiedProductsListView.setVisibility(View.GONE);

        verifyFab = findViewById(R.id.verify_fab);
        verifyFab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                verifyDialog(v);
            }
        });

    }

    private void verifyDialog(final View view) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(context);
        View dialogView = this.getLayoutInflater().inflate(R.layout.verify_dialog, null);
        dialog.setView(dialogView);
        final EditText verificationCodeEditText = (EditText) dialogView.findViewById(R.id.verification_code_edit_text);

        dialog.setTitle("Check Product Code");

        dialog.setPositiveButton("Check code", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                connectivityManager = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager != null) {
                    networkInfo = connectivityManager.getActiveNetworkInfo();
                }
//        NetworkInfo networkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
                if (networkInfo != null) {
                    isNetworkConnect = networkInfo.isConnected();
                }
                if (networkInfo != null && isNetworkConnect) {

                    boolean cancel = false;
                    View focusView = null;
                    String  mVerificationCode = verificationCodeEditText.getText().toString();
                    verificationCodeEditText.setError(null);
                    if (TextUtils.isEmpty(mVerificationCode) || mVerificationCode.equals(" ")){
                        cancel = true;
                    } if (cancel) {
                       Toast toast =  Toast.makeText(VerificationActivity.this, "Please input a verification code", Toast.LENGTH_LONG);
                        LinearLayout layout  = (LinearLayout) toast.getView();
                        TextView messageTextView = (TextView) layout.getChildAt(0);
                        messageTextView.setTextSize(20);
                        toast.show();

                    } else {
                        progressBar.setVisibility(View.VISIBLE);
                        progressBar.bringToFront();
                        VerificationAsyncTask verificationAsyncTask = new VerificationAsyncTask();
                        verificationAsyncTask.execute(mVerificationCode);
                    }
                }
                else {
                    Snackbar snackbar = Snackbar.make(view, "No internet connection!", Snackbar.LENGTH_SHORT);
                    View snackBarView = snackbar.getView();
                    snackBarView.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));
                    TextView textView = (TextView) snackBarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(context.getResources().getColor(R.color.white));
                    snackbar.show();
                }
            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog builder = dialog.create();
        builder.show();
    }


   private long addVerifiedProductToDb(ProductDetails productDetails){
        String currentProductName, currentManufacturer, currentExpirationDate, currentVerificationCode;
        currentProductName = productDetails.getmProductName();
        currentManufacturer = productDetails.getmManufacturer();
        currentExpirationDate = productDetails.getmExpirationDate();
        currentVerificationCode = productDetails.getmVerificationCode();

       ContentValues cv = new ContentValues();
       cv.put(ProductsContract.ProductsEntry.COLUMN_PRODUCT_NAME, currentProductName);
       Log.i(TAG, "addVerifiedProductToDb: " + currentProductName);
       cv.put(ProductsContract.ProductsEntry.COLUMN_MANUFACTURER_NAME, currentManufacturer);
       Log.i(TAG, "addVerifiedProductToDb: " + currentManufacturer);
       cv.put(ProductsContract.ProductsEntry.COLUMN_EXPIRATION_DATE, currentExpirationDate);
       cv.put(ProductsContract.ProductsEntry.COLUMN_VERIFICATION_CODE, currentVerificationCode);


       return sqLiteDatabase.insert(ProductsContract.ProductsEntry.TABLE_NAME, null, cv);
   }

   private boolean removeVerifiedProductFromDb(long id){
       return sqLiteDatabase.delete(ProductsContract.ProductsEntry.TABLE_NAME,
               ProductsContract.ProductsEntry._ID + "=" + id,
               null) > 0;
   }

   private Cursor getAllVerifiedProducts(){
       Cursor theCursor = sqLiteDatabase.query(ProductsContract.ProductsEntry.TABLE_NAME,
               null,
               null,
               null,
               null,
               null,
               ProductsContract.ProductsEntry._ID);
       return theCursor;
   }

   private ArrayList<ProductDetails> loadVerifiedProductsFromCursor(Cursor cursor){
       int cursorSize = cursor.getCount();

       Log.i(TAG, "loadVerifiedProductsFromCursor: " + cursorSize);
       ArrayList<ProductDetails> productDetailsArrayList = new ArrayList<>();

           for (int i = 0; i <= cursorSize; i++) {

               if (cursor.moveToPosition(i)) {
                   ProductDetails productDetails = new ProductDetails(
                           cursor.getString(cursor.getColumnIndex(ProductsContract.ProductsEntry.COLUMN_PRODUCT_NAME)),
                           cursor.getString(cursor.getColumnIndex(ProductsContract.ProductsEntry.COLUMN_MANUFACTURER_NAME)),
                           cursor.getString(cursor.getColumnIndex(ProductsContract.ProductsEntry.COLUMN_EXPIRATION_DATE)),
                           cursor.getString(cursor.getColumnIndex(ProductsContract.ProductsEntry.COLUMN_VERIFICATION_CODE)));
                   Log.i(TAG, "loadVerifiedProductsFromCursor: " + cursor.getColumnIndex(ProductsContract.ProductsEntry.COLUMN_PRODUCT_NAME));

                   productDetailsArrayList.add(productDetails);
               }
           }
       return productDetailsArrayList;
   }


    private class VerificationAsyncTask extends AsyncTask<String, Void, Void>{
        ArrayList<ProductDetails> queryProducts = new ArrayList<>();
        ResponseModel responseModel = new ResponseModel(false, null);
        @Override
        protected Void doInBackground(final String... strings) {

            firebaseFirestore.collection("product_details")
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                for (DocumentSnapshot document : task.getResult()) {
                                    ProductDetails productDetails = document.toObject(ProductDetails.class);
                                    queryProducts.add(productDetails);
                                }
                                for (ProductDetails productDetail : queryProducts) {
                                    if (strings.length<1 || strings[0] == null){
                                        return;
                                    }
                                    if (productDetail.getmVerificationCode().equals(strings[0])){
                                        responseModel = new ResponseModel(true, productDetail);
                                        Log.i(TAG, "run: product name" + productDetail.getmProductName());
                                        break;
                                    }                                }

                                boolean codeExists =  responseModel.isCodeExists();

                                if (codeExists) {
                                    ProductDetails currentProductDetail = responseModel.getCurrentProductDetails();
                                    Toast toast = Toast.makeText(VerificationActivity.this, "This product is authentic!", Toast.LENGTH_SHORT);
                                    LinearLayout layout  = (LinearLayout) toast.getView();
                                    TextView messageTextView = (TextView) layout.getChildAt(0);
                                    messageTextView.setTextSize(20);
                                    toast.show();
                                    addVerifiedProductToDb(currentProductDetail);
                                    verifiedProductsAdapter = new ProductDetailsAdapter(VerificationActivity.this,
                                            loadVerifiedProductsFromCursor(getAllVerifiedProducts()));
                                    verifiedProductsListView.setAdapter(verifiedProductsAdapter);
                                    progressBar.setVisibility(View.GONE);
                                }
                                else {
                                    progressBar.setVisibility(View.GONE);
                                    Toast toast = Toast.makeText(VerificationActivity.this, "Code doesnt exist", Toast.LENGTH_SHORT);
                                    LinearLayout layout  = (LinearLayout) toast.getView();
                                    TextView messageTextView = (TextView) layout.getChildAt(0);
                                    messageTextView.setTextSize(20);
                                    toast.show();

                                }


                            } else {
                                Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                                progressBar.setVisibility(View.GONE);
                                Log.d(TAG, "Error getting documents: ", task.getException());
                            }
                        }
                    });

            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {

        }
    }

}
