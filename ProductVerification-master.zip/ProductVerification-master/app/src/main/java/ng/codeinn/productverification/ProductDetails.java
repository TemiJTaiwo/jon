package ng.codeinn.productverification;

/**
 * Created by Jer on 19/03/2018.
 */

public class ProductDetails {
    private String mProductName,
            mManufacturer,
            mExpirationDate,
            mVerificationCode;

    public ProductDetails() {
    }

    public ProductDetails(String mProductName, String mManufacturer, String mExpirationDate, String mVerificationCode) {
        this.mProductName = mProductName;
        this.mManufacturer = mManufacturer;
        this.mExpirationDate = mExpirationDate;
        this.mVerificationCode = mVerificationCode;
    }

    public String getmProductName() {
        return mProductName;
    }

    public void setmProductName(String mProductName) {
        this.mProductName = mProductName;
    }

    public String getmManufacturer() {
        return mManufacturer;
    }

    public void setmManufacturer(String mManufacturer) {
        this.mManufacturer = mManufacturer;
    }

    public String getmExpirationDate() {
        return mExpirationDate;
    }

    public void setmExpirationDate(String mExpirationDate) {
        this.mExpirationDate = mExpirationDate;
    }

    public String getmVerificationCode() {
        return mVerificationCode;
    }

    public void setmVerificationCode(String mVerificationCode) {
        this.mVerificationCode = mVerificationCode;
    }
}
