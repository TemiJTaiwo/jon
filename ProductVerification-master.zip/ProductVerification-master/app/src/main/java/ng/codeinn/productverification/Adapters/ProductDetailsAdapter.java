package ng.codeinn.productverification.Adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

import ng.codeinn.productverification.ProductDetails;
import ng.codeinn.productverification.R;

/**
 * Created by Jer on 19/03/2018.
 */

public class ProductDetailsAdapter extends ArrayAdapter<ProductDetails> {
    public ProductDetailsAdapter(@NonNull Context context,  ArrayList<ProductDetails> productDetailsList) {
        super(context, 0, productDetailsList);

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        if (convertView == null){
            convertView = LayoutInflater.from(getContext()).
                    inflate(R.layout.verfied_list_item, parent, false);

        }

        ProductDetails currentProduct = getItem(position);
        TextView productNameTV = convertView.findViewById(R.id.product_name_tv),
                manufacturerTV = convertView.findViewById(R.id.manufacturer_tv),
                expirationDateTV = convertView.findViewById(R.id.expiration_date_tv),
                verificationCodeTV = convertView.findViewById(R.id.verification_code_tv);

        if (currentProduct != null){
            productNameTV.setText(currentProduct.getmProductName());
            manufacturerTV.setText(currentProduct.getmManufacturer());
            expirationDateTV.setText(currentProduct.getmExpirationDate());
            verificationCodeTV.setText(currentProduct.getmVerificationCode());
        }

        return convertView;
    }
}
