package ng.codeinn.productverification;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.firestore.FirebaseFirestore;

public class AddProductActivity extends AppCompatActivity {

    private EditText productNameEditText,
            manufacturerEditText,
            expirationDateEditText,
            verificationCodeEditText;

    private TextView addProductTextView;

    private String productName,
            manufacturer,
            expirationDate,
            verificationCode;

    private FirebaseFirestore firestore;

    private NetworkInfo networkInfo;
    private ConnectivityManager connectivityManager;
    private boolean isNetworkConnect;
    private Context context;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_product);

        firestore = FirebaseFirestore.getInstance();
        context = this;

        productNameEditText = findViewById(R.id.set_product_name);
        manufacturerEditText = findViewById(R.id.set_manufacturer);
        expirationDateEditText = findViewById(R.id.set_expiration_date);
        verificationCodeEditText = findViewById(R.id.set_verification_code);

        addProductTextView = findViewById(R.id.add_product_tv);
        addProductTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                connectivityManager = (ConnectivityManager)
                        getSystemService(Context.CONNECTIVITY_SERVICE);
                if (connectivityManager != null) {
                    networkInfo = connectivityManager.getActiveNetworkInfo();
                }
//        NetworkInfo networkInfo = connectivityManager != null ? connectivityManager.getActiveNetworkInfo() : null;
                if (networkInfo != null) {
                    isNetworkConnect = networkInfo.isConnected();
                }
                if (networkInfo != null && isNetworkConnect) {

                addProduct();
                }
                else {
                    Snackbar snackbar = Snackbar.make(v, "No internet connection!", Snackbar.LENGTH_SHORT);
                    View snackBarView = snackbar.getView();
                    snackBarView.setBackgroundColor(context.getResources().getColor(R.color.colorAccent));
                    TextView textView = (TextView) snackBarView.findViewById(android.support.design.R.id.snackbar_text);
                    textView.setTextColor(context.getResources().getColor(R.color.white));
                    snackbar.show();
                }
            }
        });

    }

    private void addProduct(){
        productNameEditText.setError(null);
        manufacturerEditText.setError(null);
        expirationDateEditText.setError(null);
        verificationCodeEditText.setError(null);

        productName = productNameEditText.getText().toString().trim();
        manufacturer = manufacturerEditText.getText().toString().trim();
        expirationDate = expirationDateEditText.getText().toString().trim();
        verificationCode = verificationCodeEditText.getText().toString().trim();

        boolean cancel = false;
        View focusView = null;

        if (TextUtils.isEmpty(productName) || productName.equals(" ")){
            productNameEditText.setError("input a product name");
            focusView = productNameEditText;
            cancel = true;
        }

        if (TextUtils.isEmpty(manufacturer) || manufacturer.equals(" ")){
            manufacturerEditText.setError("input a manufacturer");
            focusView = manufacturerEditText;
            cancel = true;
        }
        if (TextUtils.isEmpty(expirationDate) || expirationDate.equals(" ")){
            expirationDateEditText.setError("input a product name");
            focusView = expirationDateEditText;
            cancel = true;
        }
        if (TextUtils.isEmpty(verificationCode) || verificationCode.equals(" ")){
            verificationCodeEditText.setError("input a product name");
            focusView = verificationCodeEditText;
            cancel = true;
        }

        if (cancel) {
            focusView.requestFocus();
        } else {
            ProductDetails productDetails = new ProductDetails(productName, manufacturer, expirationDate, verificationCode);
            firestore.collection("product_details").document(productName).set(productDetails);
            startActivity(new Intent(AddProductActivity.this, AdminActivity.class));
            finish();
        }


    }
}
