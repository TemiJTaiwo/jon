package ng.codeinn.productverification.data;

/**
 * Created by Jer on 22/03/2018.
 */

public class AdminPassword {
   private String password;

    public AdminPassword() {
    }

    public AdminPassword(String password) {
        this.password = password;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
