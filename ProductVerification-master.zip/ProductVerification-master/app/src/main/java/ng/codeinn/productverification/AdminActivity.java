package ng.codeinn.productverification;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AlertDialog;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.Arrays;

import ng.codeinn.productverification.Adapters.ProductDetailsAdapter;
import ng.codeinn.productverification.data.AdminPassword;
import ng.codeinn.productverification.data.AdminUsers;

public class AdminActivity extends AppCompatActivity
        implements NavigationView.OnNavigationItemSelectedListener {

    private static final String TAG = "Tag";
    private FirebaseFirestore firebaseFirestore;
    private Context context;
    private ArrayList<ProductDetails> verifiedProductsList;
    private ListView verifiedProductsListView;
    private ProductDetailsAdapter verifiedProductsAdapter;
    private ProgressBar progressBar;


    private FirebaseAuth mFirebaseAuth;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    public static final int RC_SIGN_IN = 1;

    private String mUsername;
    AdminUsers adminUsers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        mFirebaseAuth = FirebaseAuth.getInstance();


        mAuthStateListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null){
                    mUsername = user.getDisplayName();

                }else {
                    startActivityForResult(
                            AuthUI.getInstance()
                                    .createSignInIntentBuilder()
                                    .setIsSmartLockEnabled(false)
                                    .setAvailableProviders(
                                            Arrays.asList(new AuthUI.IdpConfig.Builder(AuthUI.EMAIL_PROVIDER).build(),
                                                    new AuthUI.IdpConfig.Builder(AuthUI.GOOGLE_PROVIDER).build()))
                                    .build(),
                            RC_SIGN_IN);
                }

            }
        };

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.add_product_fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
             startActivity(new Intent(AdminActivity.this, AddProductActivity.class));
             finish();
            }
        });

        context = this;

        adminUsers = new AdminUsers();

        firebaseFirestore = FirebaseFirestore.getInstance();
        verifiedProductsList = new ArrayList<>();
        getAddedProducts();


        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        View headerView =  navigationView.getHeaderView(0);
        TextView usernameTextView = (TextView) headerView.findViewById(R.id.user_name_header);
        usernameTextView.setText(mUsername);
        navigationView.setNavigationItemSelectedListener(this);


    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.admin, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.nav_verification_activity) {
            startActivity(new Intent(AdminActivity.this, VerificationActivity.class));
            finish();
        } else if (id == R.id.nav_sign_out) {
            mFirebaseAuth.signOut();
            if (mFirebaseAuth.getCurrentUser() == null){
                startActivity(new Intent(AdminActivity.this, SplashScreen.class));
                finish();
            }
        } else if (id == R.id.nav_share) {

        }else if (id == R.id.create_admin){
            addAdminDialog();
        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }


    private void getAddedProducts(){

        firebaseFirestore.collection("product_details")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            for (DocumentSnapshot document : task.getResult()) {
                                Log.d(TAG, document.getId() + " => " + document.getData());
                                ProductDetails productDetails = document.toObject(ProductDetails.class);
                                verifiedProductsList.add(productDetails);
                                verifiedProductsListView = (ListView) findViewById(R.id.products_list_view);

                                verifiedProductsAdapter = new ProductDetailsAdapter(AdminActivity.this, verifiedProductsList);
                                verifiedProductsListView.setAdapter(verifiedProductsAdapter);
                            }
                        }else {
                            Log.d(TAG, "Error getting documents: ", task.getException());
                        }
                    }
                });
    }


    private void addAdminDialog(){
        AlertDialog.Builder dialog = new AlertDialog.Builder(this);
        View dialogView = this.getLayoutInflater().inflate(R.layout.create_admin_dialog, null);
        dialog.setView(dialogView);
        final EditText passwordEdit = (EditText) dialogView.findViewById(R.id.password_edit);
        final EditText verifyPasswordEdit = dialogView.findViewById(R.id.verify_password);

        dialog.setTitle("Create password");
        dialog.setPositiveButton("Create", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                passwordEdit.setError(null);
                verifyPasswordEdit.setError(null);

                String password = passwordEdit.getText().toString();
                String verifyPassword = verifyPasswordEdit.getText().toString();


                boolean cancel = false;
                View focusView = null;

                if (TextUtils.isEmpty(password) || password.equals(" ")){
                    passwordEdit.setError("input a password");
                    focusView = passwordEdit;
                    cancel = true;
                }

                if (TextUtils.isEmpty(verifyPassword) || !(password.equals(verifyPassword))){
                    verifyPasswordEdit.setError("Passwords do not match");
                    focusView = verifyPasswordEdit;
                    cancel = true;
                }
                if (cancel) {
                    focusView.requestFocus();
                } else {
                    AdminPassword adminPassword = new AdminPassword(password);
                    firebaseFirestore.collection("admin_password").document(password).set(adminPassword);
                }

            }
        });
        dialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });
        AlertDialog builder = dialog.create();
        builder.show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN){
            if (resultCode == RESULT_OK){
                Toast.makeText(this, "Signed in as "+adminUsers.getUsername(mFirebaseAuth)+"!!", Toast.LENGTH_SHORT).show();
            }else if (resultCode == RESULT_CANCELED){
                Toast.makeText(this, "Sign in cancelled!!", Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mAuthStateListener != null){
            mFirebaseAuth.addAuthStateListener(mAuthStateListener);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mAuthStateListener != null){
            mFirebaseAuth.removeAuthStateListener(mAuthStateListener);

        }
    }
}
