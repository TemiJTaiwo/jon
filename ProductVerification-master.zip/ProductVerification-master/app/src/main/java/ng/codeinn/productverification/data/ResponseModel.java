package ng.codeinn.productverification.data;

import ng.codeinn.productverification.ProductDetails;

/**
 * Created by Jer on 20/03/2018.
 */

public class ResponseModel {

    private boolean codeExists;
    private ProductDetails currentProductDetails;

    public ResponseModel() {
    }

    public ResponseModel(boolean codeExists, ProductDetails currentProductDetails) {
        this.codeExists = codeExists;
        this.currentProductDetails = currentProductDetails;
    }

    public boolean isCodeExists() {
        return codeExists;
    }

    public void setCodeExists(boolean codeExists) {
        this.codeExists = codeExists;
    }

    public ProductDetails getCurrentProductDetails() {
        return currentProductDetails;
    }

    public void setCurrentProductDetails(ProductDetails currentProductDetails) {
        this.currentProductDetails = currentProductDetails;
    }
}
