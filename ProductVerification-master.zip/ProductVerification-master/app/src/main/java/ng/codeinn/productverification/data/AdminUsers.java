package ng.codeinn.productverification.data;

import android.support.annotation.NonNull;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

/**
 * Created by Jer on 22/03/2018.
 */

public class AdminUsers {

    public  String getUsername(FirebaseAuth firebaseAuth){
        FirebaseUser user = firebaseAuth.getCurrentUser();

        String username;

        if (user != null) {
            username = user.getDisplayName();
        }else {
            username = "Anonymous";
        }
        return username;
    }

}

